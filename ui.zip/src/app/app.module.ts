import { NgtUniversalModule } from '@ng-toolkit/universal';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { TransferHttpCacheModule } from '@nguniversal/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { HeaderComponent } from './dashboard/header/header.component';
import { AppRoutingModule } from './app-routing.module';
import { DropdownDirective } from './shared/dropdown.directive';
import { DataStorageService } from './shared/data-storage.service';
import { PostListComponent } from './post/post-list/post-list.component';
import { PostDetailsComponent } from './post/post-details/post-details.component';
import { PostItemComponent } from './post/post-list/post-item/post-item.component';
import { PostService } from './post/posts.service';

import { FooterComponent } from './dashboard/footer/footer.component';
import { PlanDetailsComponent } from './plan/plan-details/plan-details.component';
import { PlanListComponent } from './plan/plan-list/plan-list.component';
import { PlanItemComponent } from './plan/plan-list/plan-item/plan-item.component';
import { PlanService } from './plan/plans.service';
import { DashboardComponent } from './dashboard/dashboard.component';

import { BrowserModule } from '@angular/platform-browser';

@NgModule({
  bootstrap: [AppComponent],
  declarations: [
    AppComponent,
    HeaderComponent,
    DropdownDirective,
    PostListComponent,
    PostDetailsComponent,
    PostItemComponent,
    FooterComponent,
    PlanDetailsComponent,
    PlanListComponent,
    PlanItemComponent,
    DashboardComponent

  ],
  imports:[
    BrowserModule.withServerTransition({appId: 'my-app'}),
    CommonModule,
    NgtUniversalModule,
 
    TransferHttpCacheModule,
    HttpClientModule,
 
    
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [PlanService, DataStorageService, PostService],

  
    
})
export class AppModule { }
