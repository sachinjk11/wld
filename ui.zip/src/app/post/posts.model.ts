

export class Post
{
   public title : string;
   public desc : string;

   constructor(title : string, desc : string )
   {
        this.title = title;
        this.desc = desc;
   }
}